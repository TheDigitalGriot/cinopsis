# Cinopsis — griot-brand-matrix brief (filled)

| token | value |
|---|---|
| `APP_NAME` | Cinopsis |
| `APP_NAME_LOWER` | cinopsis |
| `ICON_LETTER` | C  *(final mark = the logo Gavin attaches)* |
| `VERSION` | v2.1.2 |
| `SHORT_DESCRIPTOR` | recorded-video analyzer |

**`ONE_LINE_WHAT_IT_IS`** — Recorded-video / YouTube analyzer + multi-video comparison engine
(*ciné + opsis* — "to see cinema"): fetches transcripts, runs cross-video
topic / disagreement / key-moment analysis, captures frames, opens an agentic chat over the set.
Ecosystem: feeds digests as Synaptiq nodes; becomes a Synaptiq plugin.

**`CORE_FEELING`** — a film editor's console / signal-room: dark, precise, a red record-light of
attention; many streams in, the signal pulled out. Cinematic clarity, not a media player.

**`THING_TO_AVOID`** — a generic YouTube-clone red; and glassmorphism carpet-bombing (glass must
*earn* its place — see the treatment budget below).

**`GEOMETRY_RULES`** — defined by the attached logo. Wordmark = real **Afrik "Cinopsis"** composited
in the header (COMPOSITE MODE: ON). Let Gavin pick the Afrik stylistic set / per-letter alternates
from the generator's sheet.

## Colours — the locked YT-Red direction (2026-06-11)
| role | hex | name |
|---|---|---|
| `EMBER_HEX` (primary) | `#EF233C` | **YT Red** — Cinopsis's custom ember |
| ember deep (hover/glow) | `#D90429` | YT Deep |
| `SECONDARY_HEX` (panels) | `#2B2D42` | Navy |
| muted / `DEBUG_HEX` | `#8D99AE` | Slate — labels |
| text | `#EDF2F4` | Chalk |
| `BG_HEX` | `#0D0D0D` | Void — canvas |

**`EMBER_NAME`** = YT Red.  (Register as a *custom* Cinopsis ember; overrides Griotwave's reserved
danger-red because the app's role literally is video/YouTube.)

## The five-treatment system (drives the mockup panel, not the logo grid)
"Glass only where it earns it — every widget gets its own treatment, no default carpet-bombing."
Sidebar = the **Workly move**: one item glows red, the rest flat.

1. **Gradient Red** — brand stat · videos count · active badge
2. **Flat Dark** — low-signal stats · inactive sessions
3. **Glass** — unified summary · key-insight cards
4. **Accent Top** — topic cards · per-video entries · data rows
5. **Full Bleed** — chat bubble · CTA cards · key-moment highlights

This is also a **Griotwave extension rule** ("treatment budgets per zone") the direction wants
folded back into the design system.
